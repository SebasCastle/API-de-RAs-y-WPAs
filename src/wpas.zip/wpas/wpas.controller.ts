import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { WorkerResultsDto } from './dto/worker-results.dto';
import { WpasService } from './wpas.service';

@Controller('wpas')
export class WpasController {
  constructor(private readonly wpasService: WpasService) {}

  @Get('worker-config')
  getWorkerConfiguration() {
    return this.wpasService.getWorkerConfiguration();
  }

  @Get('reservas')
  getReservations() {
    return this.wpasService.getReservations();
  }

  @Post('resultados')
  saveResults(@Body() results: WorkerResultsDto) {
    return this.wpasService.saveResults(results);
  }

  @Get()
  findAll() {
    return this.wpasService.findAll();
  }

  @Get(':id')
  getWpa(@Param('id') id: string) {
    return this.wpasService.getWpa(id);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.wpasService.remove(id);
  }
}
