import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { WPA, WpaSchema } from './entities/wpa.entity';
import { WpasService } from './wpas.service';
import { WpasController } from './wpas.controller';

@Module({
  imports: [MongooseModule.forFeature([{ name: WPA.name, schema: WpaSchema }])],
  controllers: [WpasController],
  providers: [WpasService],
})
export class WpasModule {}
