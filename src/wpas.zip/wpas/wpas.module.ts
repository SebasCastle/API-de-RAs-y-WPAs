import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { WPA, WpaSchema } from "./entities/wpa.entity";
import { WpaController } from "./wpas.controller";
import { WpasService } from "./wpas.service";

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: WPA.name,
        schema: WpaSchema,
      },
    ]),
  ],
  controllers: [WpaController],
  providers: [WpasService],
  exports: [WpasService],
})
export class WpasModule {}
