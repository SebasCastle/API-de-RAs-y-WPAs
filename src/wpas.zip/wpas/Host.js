/******************************************************************************
 * Host.js
 * Unico adaptador autorizado para interactuar con BlueZone.
 ******************************************************************************/

var Host = {
    Initialize: function () {
        if (!host)
            throw new Error("El objeto BlueZone no esta inicializado.");
        Logger.Info("Host inicializado.");
        return true;
    },

    Execute: function (method, action) {
        try {
            return action();
        }
        catch (e) {
            return this.HandleError(method, e);
        }
    },

    Connect: function () {
        var sessions = [BLUEZONE.Session, BLUEZONE.FallbackSession];
        for (var i = 0; i < sessions.length; i++) {
            try {
                Logger.Info("Conectando al Host, sesion " + (sessions[i] || "activa") + ".");
                var result = host.Connect(sessions[i]);
                if (result == 0 || typeof result == "undefined") {
                    this.WaitReady();
                    STATUS.Connected = true;
                    return true;
                }
            }
            catch (e) {
                Logger.Warn("No fue posible conectar la sesion " + (sessions[i] || "activa") + ".");
            }
        }
        Logger.Error("No fue posible conectar con BlueZone.");
        return false;
    },

    Disconnect: function () {
        return this.Execute("Disconnect", function () {
            host.Disconnect();
            STATUS.Connected = false;
            Logger.Info("Sesion desconectada.");
            return true;
        });
    },

    WaitReady: function () {
        return this.Execute("WaitReady", function () {
            host.WaitReady(TIMEOUT.WaitReady, 1000);
            return true;
        });
    },

    Sleep: function (milliseconds) {
        WScript.Sleep(milliseconds);
    },

    HandleError: function (method, error) {
        Logger.Error("[" + method + "] " + (error.message || error));
        return false;
    },

    SendKeys: function (keys) {
        return this.Execute("SendKeys", function () {
            if (!keys)
                throw new Error("No se especificaron teclas.");
            host.SendKey(keys);
            host.WaitReady(TIMEOUT.WaitReady, 1000);
            return true;
        });
    },

    Enter: function () { return this.SendKeys("@E"); },
    Tab: function () { return this.SendKeys("@T"); },
    Clear: function () { return this.SendKeys("@C"); },
    EraseEOF: function () { return this.SendKeys("@F"); },
    PF: function (number) {
        if (number < 1 || number > 24) {
            Logger.Error("PF invalida: " + number);
            return false;
        }
        return this.SendKeys("<PF" + number + ">");
    },

    ReadText: function (row, column, length) {
        return this.Execute("ReadText", function () {
            if (row < 1 || column < 1 || length <= 0)
                throw new Error("Coordenadas de lectura invalidas.");
            var buffer = new Object();
            buffer.Str = "";
            host.ReadScreen(buffer, length, row, column);
            return buffer.Str || "";
        });
    },

    ReadRow: function (row) {
        return this.ReadText(row, 1, BLUEZONE.Columns);
    },

    GetScreenText: function () {
        var text = "";
        for (var row = 1; row <= BLUEZONE.Rows; row++)
            text += (this.ReadRow(row) || "") + "\n";
        return text;
    },

    ScreenContains: function (text) {
        return this.GetScreenText().toUpperCase().indexOf(text.toUpperCase()) != -1;
    },

    FindText: function (text) {
        var target = text.toUpperCase();
        for (var row = 1; row <= BLUEZONE.Rows; row++) {
            var value = this.ReadRow(row);
            var column = value.toUpperCase().indexOf(target);
            if (column != -1)
                return { Row: row, Column: column + 1 };
        }
        return null;
    },

    WriteText: function (row, column, text) {
        return this.Execute("WriteText", function () {
            if (text == null)
                throw new Error("Texto invalido.");
            host.WriteScreen(text.toString(), row, column);
            return true;
        });
    },

    Navigate502: function () {
        if (!this.Clear())
            return false;
        if (!this.SendKeys("502"))
            return false;
        if (!this.Enter())
            return false;
        this.Sleep(TIMEOUT.AfterCommand);
        return true;
    }
};
