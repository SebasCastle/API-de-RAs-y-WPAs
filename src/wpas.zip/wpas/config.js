/******************************************************************************
 * Config.js
 * Configuracion global del Worker BlueZone. No contiene logica de negocio.
 ******************************************************************************/

var WORKER = {
    Name: "AWS-WPA-01",
    Version: "1.0.0",
    Environment: "DEV"
};

var BLUEZONE = {
    Session: "A",
    FallbackSession: "",
    Rows: 24,
    Columns: 80
};

var RESERVATIONS = {
    Source: "FILE",
    File: "D:\\Downloads\\lista_reservaciones.txt"
};

var PATH = {
    Root: "C:\\BlueZoneWorker\\",
    Logs: "C:\\BlueZoneWorker\\Logs\\",
    Temp: "C:\\BlueZoneWorker\\Temp\\"
};

var API = {
    BaseUrl: "http://localhost:3000/api/sync",
    Token: "",
    ConfigurationPath: "/wpas/worker-config",
    ReservationsPath: "/wpas/reservas",
    ResultsPath: "/wpas/resultados"
};

var RACF = {
    User: "",
    Password: "",
    NewPassword: ""
};

var TIMEOUT = {
    WaitReady: 10,
    WaitText: 10,
    Login: 30,
    AfterCommand: 1000,
    AfterLoginStep: 1000,
    AfterReservationSearch: 2000
};

var PROCESS = {
    MaxAttempts: 2,
    FixedWpaRow: 12,
    FixedWpaColumn: 21,
    FixedWpaLength: 4
};

var STATUS = {
    Connected: false,
    Logged: false,
    PasswordChanged: false,
    InMenu: false,
    Running: false
};

var host = new ActiveXObject("BZWhll.WhllObj");
var fso = new ActiveXObject("Scripting.FileSystemObject");
var shell = new ActiveXObject("WScript.Shell");

function LoadConfiguration(config) {
    if (!config)
        return false;

    if (config.baseUrl)
        API.BaseUrl = config.baseUrl;
    if (config.token)
        API.Token = config.token;
    if (config.session)
        BLUEZONE.Session = config.session;
    if (config.fallbackSession)
        BLUEZONE.FallbackSession = config.fallbackSession;
    if (config.racfUser)
        RACF.User = config.racfUser;
    if (config.password)
        RACF.Password = config.password;
    if (config.newPassword)
        RACF.NewPassword = config.newPassword;
    if (config.reservationsSource)
        RESERVATIONS.Source = config.reservationsSource;
    if (config.reservationsFile)
        RESERVATIONS.File = config.reservationsFile;
    if (config.resultsPath)
        API.ResultsPath = config.resultsPath;
    if (config.reservationsPath)
        API.ReservationsPath = config.reservationsPath;

    return true;
}
