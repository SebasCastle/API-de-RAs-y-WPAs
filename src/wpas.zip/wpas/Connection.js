/******************************************************************************
 * Connection.js
 * Establece una sesion valida y deja BlueZone en PMENU.
 ******************************************************************************/

var Connection = {
    Login: function () {
        Logger.Info("Iniciando sesion.");
        if (!Host.Initialize() || !Host.Connect())
            return false;
        if (!this.DoLogin())
            return false;
        if (!this.ValidateLogin())
            return false;
        if (!this.GoToPmenu())
            return false;

        STATUS.Logged = true;
        STATUS.InMenu = true;
        Logger.Info("Sesion iniciada correctamente.");
        return true;
    },

    DoLogin: function () {
        if (!RACF.User || !RACF.Password) {
            Logger.Error("No se recibieron credenciales RACF.");
            return false;
        }

        if (!Host.SendKeys("ims") || !Host.Enter())
            return false;
        Host.Sleep(TIMEOUT.AfterLoginStep);
        if (!Host.SendKeys(RACF.User))
            return false;
        Host.Sleep(TIMEOUT.AfterLoginStep);
        if (!Host.SendKeys(RACF.Password) || !Host.Enter())
            return false;
        Host.Sleep(TIMEOUT.AfterLoginStep);
        return true;
    },

    ValidateLogin: function () {
        if (Host.ScreenContains("PASSWORD EXPIRED"))
            return this.ChangePassword();

        if (Host.ScreenContains("NOT AUTHORIZED") ||
            Host.ScreenContains("REVOKED") ||
            Host.ScreenContains("INVALID PASSWORD")) {
            Logger.Error("BlueZone rechazo las credenciales RACF.");
            return false;
        }

        return true;
    },

    ChangePassword: function () {
        Logger.Warn("Cambio de contrasena requerido.");
        if (!RACF.NewPassword) {
            Logger.Error("No se recibio la nueva contrasena RACF.");
            return false;
        }

        if (!Host.SendKeys(RACF.User) ||
            !Host.SendKeys(RACF.Password) ||
            !Host.SendKeys(RACF.NewPassword) ||
            !Host.Enter())
            return false;
        Host.Sleep(TIMEOUT.AfterLoginStep);

        if (!Host.ScreenContains("PLEASE RE-ENTER NEW PASSWORD")) {
            Logger.Error("No aparecio la confirmacion del cambio de contrasena.");
            return false;
        }

        if (!Host.SendKeys(RACF.NewPassword) || !Host.Enter())
            return false;
        Host.Sleep(TIMEOUT.AfterLoginStep);

        if (!Host.ScreenContains("PWD-CHG")) {
            Logger.Error("BlueZone no confirmo el cambio de contrasena.");
            return false;
        }

        if (!Host.Enter())
            return false;
        Host.Sleep(TIMEOUT.AfterLoginStep);
        RACF.Password = RACF.NewPassword;
        STATUS.PasswordChanged = true;
        return true;
    },

    GoToPmenu: function () {
        if (!Host.SendKeys("/for pmenu") || !Host.Enter())
            return false;
        Host.Sleep(TIMEOUT.AfterLoginStep);
        return true;
    },

    Logout: function () {
        Logger.Info("Finalizando sesion.");
        STATUS.Logged = false;
        STATUS.InMenu = false;
        return Host.Disconnect();
    }
};
