/******************************************************************************
 * Main.js
 * Punto de entrada ejecutable con cscript Main.js.
 ******************************************************************************/

var loaderFso = new ActiveXObject("Scripting.FileSystemObject");
var loaderFolder = loaderFso.GetParentFolderName(WScript.ScriptFullName);
var workerFiles = [
    "config.js",
    "Logger.js",
    "Host.js",
    "ApliClient.js",
    "ReservationProvider.js",
    "Connection.js",
    "Worker.js"
];

for (var workerFileIndex = 0; workerFileIndex < workerFiles.length; workerFileIndex++) {
    var workerFile = loaderFso.OpenTextFile(loaderFso.BuildPath(loaderFolder, workerFiles[workerFileIndex]), 1);
    eval(workerFile.ReadAll());
    workerFile.Close();
}

function Main() {
    var results = [];
    Logger.Start();
    STATUS.Running = true;
    try {
        var configuration = ApiClient.GetConfiguration();
        if (configuration)
            LoadConfiguration(configuration);

        if (!Connection.Login()) {
            Logger.Error("El Worker no pudo iniciar sesion.");
            return false;
        }

        results = Worker.Process();
        if (!ApiClient.SendResults(results, Worker.Stats))
            Logger.Warn("Los resultados deben reenviarse cuando el servidor este disponible.");
        Logger.Info("Resumen: " + Worker.BuildSummary());
        return true;
    }
    catch (e) {
        Logger.Error("Error no controlado en Main: " + (e.message || e));
        return false;
    }
    finally {
        STATUS.Running = false;
        if (STATUS.Connected)
            Connection.Logout();
        Logger.Finish();
    }
}

Main();
