/******************************************************************************
 * ReservationProvider.js
 * Obtiene las reservaciones sin exponer su origen al Worker.
 ******************************************************************************/

var ReservationProvider = {
    GetReservations: function () {
        if (RESERVATIONS.Source == "FILE")
            return this.GetFromFile();
        if (RESERVATIONS.Source == "API")
            return this.GetFromApi();
        Logger.Error("Origen de reservaciones no valido: " + RESERVATIONS.Source);
        return [];
    },

    GetFromFile: function () {
        var reservations = [];
        var file = null;
        try {
            if (!fso.FileExists(RESERVATIONS.File)) {
                Logger.Error("No existe el archivo de reservaciones: " + RESERVATIONS.File);
                return reservations;
            }
            file = fso.OpenTextFile(RESERVATIONS.File, 1);
            while (!file.AtEndOfStream) {
                var reservation = this.Normalize(file.ReadLine());
                if (reservation)
                    reservations.push(reservation);
            }
            Logger.Info("Reservaciones cargadas desde archivo: " + reservations.length);
        }
        catch (e) {
            Logger.Error("Error leyendo reservaciones: " + (e.message || e));
            reservations = [];
        }
        finally {
            if (file)
                file.Close();
        }
        return reservations;
    },

    GetFromApi: function () {
        var source = ApiClient.GetReservations();
        var reservations = [];
        for (var i = 0; i < source.length; i++) {
            var item = source[i];
            if (typeof item == "object")
                item = item.reservation || item.reservacion || item.resNum;
            item = this.Normalize(item);
            if (item)
                reservations.push(item);
        }
        Logger.Info("Reservaciones cargadas desde API: " + reservations.length);
        return reservations;
    },

    Normalize: function (value) {
        if (value == null)
            return "";
        return value.toString().replace(/^\s+|\s+$/g, "");
    }
};
