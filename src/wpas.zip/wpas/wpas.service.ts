import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { WorkerResultsDto } from './dto/worker-results.dto';
import { WPA } from './entities/wpa.entity';

@Injectable()
export class WpasService {
  constructor(
    @InjectModel(WPA.name)
    private readonly wpaModel: Model<WPA>,
  ) {}

  findAll() {
    return this.wpaModel.find().exec();
  }

  getWpa(id: string) {
    return this.wpaModel.findById(id).exec();
  }

  async getReservations() {
    const reservations = await this.wpaModel
      .find({
        resNum: { $exists: true, $ne: '' },
        status: { $ne: 'OK' },
      })
      .select({ resNum: 1, _id: 0 })
      .lean()
      .exec();

    return {
      reservations: reservations.map((reservation) => reservation.resNum),
    };
  }

  async saveResults(payload: WorkerResultsDto) {
    let saved = 0;
    for (const result of payload.results) {
      await this.wpaModel.updateOne(
        { resNum: result.reservation },
        {
          $set: {
            wpa: result.wpa,
            status: result.status,
            message: result.message,
            attempts: result.attempts ?? 0,
            processedAt: new Date(),
          },
        },
        { upsert: true },
      );
      saved++;
    }

    return { received: payload.results.length, saved };
  }

  remove(id: string) {
    return this.wpaModel.deleteOne({ _id: id }).exec();
  }

  getWorkerConfiguration() {
    return {
      session: process.env.WPA_BLUEZONE_SESSION ?? 'A',
      fallbackSession: process.env.WPA_BLUEZONE_FALLBACK_SESSION ?? '',
      racfUser: process.env.WPA_RACF_USER ?? '',
      password: process.env.WPA_RACF_PASSWORD ?? '',
      newPassword: process.env.WPA_RACF_NEW_PASSWORD ?? '',
      reservationsSource: process.env.WPA_RESERVATIONS_SOURCE ?? 'FILE',
      reservationsFile: process.env.WPA_RESERVATIONS_FILE,
      resultsPath: '/wpas/resultados',
      reservationsPath: '/wpas/reservas',
    };
  }
}
