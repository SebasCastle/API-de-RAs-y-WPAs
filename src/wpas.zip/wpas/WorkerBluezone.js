// ================================================================
// CONFIGURACION Y VARIABLES GLOBALES
// ================================================================

var RACF_USER = "XMSERV02";
var RACF_NEW_PASSWORD = "Avis2027";
var RACF_PASSWORD = "Avis2027";
var acum = 6;

var host = new ActiveXObject("BZWhll.WhllObj");
var fso = new ActiveXObject("Scripting.FileSystemObject");

//contadores para el resumen
var Err = 0;
var Correcto = 0;
var Total = 0;

//contadores para resumen peteción HTTP web
// --- Contadores y Array de resultados ---
var totalLineasProcesadas = 0;
var totalCorrectos = 0;
var totalNoEncontrados = 0;
var totalConError = 0;
var primeraVez = true;

var datosParaEnviar = [];


// Constantes para archivos
var ForReading = 1;
var ForWriting = 2;
var TristateUseDefault = -2;

// Rutas de archivos (Asegurate que las rutas existan)
var rutaEntrada = "D:\\Downloads\\lista_reservaciones.txt";
var rutaSalida = "C:\\Users\\sebas\\OneDrive\\Desktop\\datos.txt";

// Tiempos de espera (Ajustar segun velocidad del sistema)
var ESPERA_CORTA = 1;
var ESPERA_LARGA = 2;

// ================================================================
// BLOQUE PRINCIPAL DE EJECUCION
// ================================================================

function Main() {
  var resultadoConexion = host.Connect("A");
  if (resultadoConexion != 0) {
    // Si falla la conexion manual, intentar conectar al B
    host.Connect("B");
  }

  // Realizar Login y navegacion inicial
  LoginNavegacionInicial();

  // Abrir archivos
  if (!fso.FileExists(rutaEntrada)) {
    host.MsgBox("El archivo de entrada no existe: " + rutaEntrada, 16);
    return;
  }

  var archivoLectura = fso.OpenTextFile(rutaEntrada, ForReading);

  // Crear archivo de salida
  // Usamos CreateTextFile con overwrite = true
  var archivoEscritura = fso.CreateTextFile(rutaSalida, true);

  // Loop principal por cada linea del archivo
  while (!archivoLectura.AtEndOfStream) {
    var lineaReserva = archivoLectura.ReadLine();

    // Limpiamos espacios en blanco de la linea
    lineaReserva = lineaReserva.replace(/^\s+|\s+$/g, '');

    if (lineaReserva.length > 0) {
      // Procesamos la reserva y obtenemos el resultado (WPA, XXXX o ERR)
      var resultado = ProcesarReserva(lineaReserva);

      // Escribir en el archivo de salida: RESERVACION:RESULTADO,
      archivoEscritura.Write(lineaReserva + ":" + resultado + ",");

      // RSalir a inicio (F12) y volver a 502
      ReiniciarCicloNavegacion();
    }
  }

  // Cerrar archivos y finalizar
  archivoLectura.Close();
  archivoEscritura.Close();

  host.MsgBox("Proceso finalizado correctamente.", 64);
}

// Ejecutar el script
Main();

// ================================================================
// FUNCIONES AUXILIARES
// ================================================================
//Cambio de contraseña
function VerificarCambioPassword() {

  host.Wait(2);

  // ¿La contraseña expiró?
  if (!PantallaContiene("12PASSWORD EXPIRED")) {
    return true; // Continuar flujo normal
  }

  // host.MsgBox("Contraseña expirada. Iniciando cambio automático...", 64);

  // ==========================================================
  // Pantalla:
  // USERID
  // OLD PASSWORD
  // NEW PASSWORD
  // ==========================================================

  host.SendKey(RACF_USER);

  host.SendKey(RACF_PASSWORD);

  RACF_NEW_PASSWORD = "Avis2027";

  host.SendKey(RACF_NEW_PASSWORD);

  host.SendKey("@E");

  host.Wait(2);

  // ==========================================================
  // Segunda pantalla
  // PLEASE RE-ENTER NEW PASSWORD
  // ==========================================================

  if (!PantallaContiene("PLEASE RE-ENTER NEW PASSWORD")) {

    // host.MsgBox("No apareció la pantalla de confirmación de contraseña.",16);

    return false;
  }

  host.SendKey(RACF_NEW_PASSWORD);
  host.SendKey("@E");

  host.Wait(2);

  // ==========================================================
  // Confirmación
  // ==========================================================

  if (!PantallaContiene("PWD-CHG")) {

    // host.MsgBox("ERROR: No se confirmó el cambio de contraseña.",16);

    return false;
  }

  // host.MsgBox("Contraseña actualizada correctamente.",64);

  host.SendKey("@E");

  host.Wait(2);

  return true;
}

//generar nueva contraseña
// function GenerarNuevaPassword() {
//     acum++;
//     return "Avis2027";
// }

//buscar texto 

function PantallaContiene(textoBuscar) {

  var Buf = new Object();

  for (var fila = 1; fila <= 24; fila++) {

    host.ReadScreen(Buf, 80, fila, 1);

    if (Buf.Str.toUpperCase().indexOf(textoBuscar.toUpperCase()) > -1) {
      return true;
    }
  }

  return false;
}


//Login inical

function LoginNavegacionInicial() {
  // Secuencia de inicio solicitada
  host.SendKey("ims");
  host.SendKey("@E");
  host.Wait(ESPERA_CORTA);

  host.SendKey(RACF_USER);
  host.Wait(ESPERA_CORTA);

  host.SendKey(RACF_PASSWORD);
  host.SendKey("@E");
  host.Wait(ESPERA_CORTA);

  // Verificar si RACF exige cambio de contraseña
  if (!VerificarCambioPassword()) {

    host.MsgBox("No fue posible continuar con el login.", 16);
    return;
  }

  host.SendKey("/for pmenu");
  host.SendKey("@E");
  host.Wait(ESPERA_CORTA);

  irPantalla502();
}

function irPantalla502() {
  // Navegar explicitamente a la pantalla 502
  host.SendKey("502");
  host.SendKey("@E");
  host.Wait(ESPERA_CORTA);
}

function ProcesarReserva(reserva) {
  var intentos = 0;
  var maxIntentos = 2;
  var errorDetectado = false;

  // Loop de reintentos
  while (intentos < maxIntentos) {
    intentos++;

    // Limpiar campo antes de escribir (Inicio + Borrar Final de Campo)
    // @0 es Home, @F es Erase EOF
    host.Wait(ESPERA_CORTA);
    host.SendKey("dr");
    host.Wait(ESPERA_CORTA);
    for (i = 0; i <= 18; i++) {
      host.SendKey("@T");
    }
    host.SendKey("r/" + reserva);
    host.SendKey("@E");
    host.Wait(ESPERA_LARGA);

    // Verificar si hay error en pantalla
    if (VerificarErrorPantalla('ERROR - SEE HIGHLIGHTED FIELDS') & VerificarErrorPantalla('NOT FOUND')) {
      errorDetectado = true;
      // Si hay error, necesitamos resetear la pantalla para reintentar
      host.SendKey("<PF12>");
      host.Wait(ESPERA_CORTA);
      host.SendKey("502");
      host.SendKey("@E");
      host.Wait(ESPERA_CORTA);

      // Si es el ultimo intento, retornamos ERR
      if (intentos >= maxIntentos) {
        Err = Err + 1;
        return "ERR";
      }
      // Si no, el loop continua y volvemos a intentar escribir
    } else {
      Correcto = Correcto + 1;
      // Si NO hay error, procedemos a buscar el WPA
      return ExtraerWPA();
    }
  }
  return "ERR";
}

function VerificarErrorPantalla(textoError) {
  // Texto que buscamos
  // var textoError = "";

  // Objeto buffer necesario para tu version de BlueZone
  var Buf = new Object();

  // Recorremos las 24 filas de la pantalla (ajusta a 25 o 43 si tu terminal es mas grande)
  for (var fila = 1; fila <= 24; fila++) {
    // Leer 80 caracteres desde la columna 1 de la fila actual
    host.ReadScreen(Buf, 80, fila, 1);

    // Convertimos a string y buscamos el texto
    var contenidoFila = Buf.Str;

    // indexOf devuelve -1 si no encuentra el texto
    if (contenidoFila.indexOf(textoError) > -1) {
      return true; // Error encontrado!
    }
  }
  return false; // No se encontro el error en ninguna fila
}

function ExtraerWPA() {
  var etiqueta = "WPA";
  var Buf = new Object();
  var BufWPA = new Object();

  // Recorrer filas buscando "WPA"
  for (var fila = 1; fila <= 24; fila++) {
    host.ReadScreen(Buf, 80, fila, 1);
    var contenidoFila = Buf.Str;

    // Buscar donde empieza "WPA" en esta linea
    var posicion = contenidoFila.indexOf(etiqueta);

    if (posicion > -1) {
      // Encontramos "WPA".
      // posicion es el �ndice (empieza en 0).
      // Si "WPA" est� en el �ndice 10, ocupa 10, 11, 12.
      // El dato deber�a estar despu�s. Sumamos longitud de etiqueta (3) + un margen.

      // Calculamos la columna exacta en BlueZone (base 1)
      // posicion + 1 (base 1) + 3 (longitud WPA) + 1 (espacio en blanco)
      var colLectura = posicion + 1 + 3;

      // A veces hay varios espacios, leemos un bloque de 10 caracteres para limpiar despues
      // Nota: Nos aseguramos de leer en la misma fila
      host.ReadScreen(BufWPA, 6, fila, colLectura);

      var valorCrudo = BufWPA.Str;

      // Limpiamos espacios (trim)
      var valorLimpio = valorCrudo.replace(/^\s+|\s+$/g, '');

      if (valorLimpio == "" || valorLimpio == " ") {
        return "0000";
      } else {
        // Tomamos solo los primeros 4 caracteres validos
        var valor4digitos = valorLimpio.substring(0, 4);
        // Estandarizamos los valores segun la tabla
        return EstandarizarValor(valor4digitos);
      }
    }
  }

  // Si terminamos el loop y no encontramos "WPA"
  return "0000";
}

function EstandarizarValor(valor) {
  // Estandarizar cada caracter seg�n la tabla:
  // A, Y -> 1
  // M -> 2
  // X -> 0

  var resultado = "";


  for (var i = 0; i < valor.length; i++) {
    var caracter = valor.charAt(i).toUpperCase();
    if (caracter === "A") {
      resultado += "4";
    }
    else if (caracter === "Y") {
      resultado += "1";
    } else if (caracter === "M") {
      resultado += "2";
    } else if (caracter === "X" || caracter === "N") {
      resultado += "0";
    } else if (caracter === "0" || caracter === "1" || caracter === "2") {
      // Los numeros se mantienen igual
      resultado += caracter;
    } else {
      // devolver caracter original
      resultado += caracter;
    }
  }

  return resultado;
}


function ReiniciarCicloNavegacion() {

  // Regresa a la menu F12
  host.SendKey("<PF12>");
  host.Wait(ESPERA_CORTA);

  // Volvemos a entrar a la 502
  irPantalla502();
}

function EnviarDatosHTTP() {
  if (datosParaEnviar.length > 0) {
    try {
      // --- 1. Construir el string JSON manualmente ---
      // El motor JScript de Bluezone es antiguo y no tiene 'JSON.stringify'
      var jsonString = "[";
      for (var i = 0; i < datosParaEnviar.length; i++) {
        jsonString += "{\"reservacion\":\"" + datosParaEnviar[i].reservacion + "\",";
        jsonString += "\"wpa\":\"" + datosParaEnviar[i].wpa + "\"}";
        if (i < datosParaEnviar.length - 1) {
          jsonString += ",";
        }
      }
      jsonString += "]";

      // --- 2. Crear y enviar la peticin HTTP ---
      var http = new ActiveXObject("MSXML2.XMLHTTP.6.0");
      var url = "http://localhost:88/Avis_bot/sincronizar.php";

      http.open("POST", url, false); // false = sncrono
      http.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      http.send(jsonString);

      // --- 3. Mostrar respuesta del servidor ---
      if (http.status == 200) {
        host.MsgBox("SINCRONIZACIN COMPLETA!\n\n" + http.responseText, 0);
      } else {
        host.MsgBox("ERROR AL SINCRONIZAR (HTTP " + http.status + ")\n\n" + http.responseText, 0);
      }

    } catch (e) {
      host.MsgBox("Error crtico al enviar datos HTTP: " + e.message, 0);
    }
  } else {
    host.MsgBox("No se encontraron datos para enviar.", 0);
  }
}


Total = Correcto + Err;

var Pantalla = "\n" +
  "resumen\n" +
  "Correctos: " + Correcto + "\n" +
  "Erroneos: " + Err + "\n" +
  "Total: " + Total + "\n" +
  "";
host.msgbox(Pantalla);
