/******************************************************************************
 * Worker.js
 * Orquesta la consulta de WPA para cada reservacion.
 ******************************************************************************/

var Worker = {
    Results: [],
    Stats: { Total: 0, Correct: 0, NotFound: 0, Error: 0 },

    Process: function (reservations) {
        Logger.Info("Inicio de procesamiento.");
        this.Results = [];
        this.ResetStats();
        if (!reservations)
            reservations = ReservationProvider.GetReservations();

        if (!reservations || reservations.length == 0) {
            Logger.Warn("No existen reservaciones por procesar.");
            return this.Results;
        }

        for (var i = 0; i < reservations.length; i++) {
            this.Stats.Total++;
            this.Results.push(this.ProcessReservation(reservations[i]));
        }
        Logger.Info("Proceso terminado. " + this.BuildSummary());
        return this.Results;
    },

    ProcessReservation: function (reservation) {
        var result = this.BuildResult(reservation);
        var completed = false;
        try {
            if (this.Open502(result)) {
                for (var attempt = 1; attempt <= PROCESS.MaxAttempts; attempt++) {
                result.attempts = attempt;
                if (!this.SearchReservation(reservation, result)) {
                    this.Stats.Error++;
                    completed = true;
                    break;
                }

                if (this.ReservationNotFound()) {
                    result.status = "NOT_FOUND";
                    result.message = "Reservacion no encontrada.";
                    this.Stats.NotFound++;
                    completed = true;
                    break;
                }

                if (this.HasScreenError()) {
                    if (attempt == PROCESS.MaxAttempts) {
                        result.status = "ERROR";
                        result.message = "BlueZone devolvio un error despues de " + attempt + " intentos.";
                        this.Stats.Error++;
                        completed = true;
                        break;
                    }
                    Logger.Warn("Error transitorio para " + reservation + ". Reintentando.");
                    this.Reset502();
                    continue;
                }

                result.wpa = this.ReadWPA();
                this.HandleEspon();
                result.success = true;
                result.status = "OK";
                this.Stats.Correct++;
                completed = true;
                break;
                }
            }
            else {
                completed = true;
            }

            if (!completed && !result.status) {
                result.status = "ERROR";
                result.message = "No fue posible procesar la reservacion.";
                this.Stats.Error++;
            }
        }
        catch (e) {
            Logger.Error("Error procesando " + reservation + ": " + (e.message || e));
            result.status = "ERROR";
            result.message = e.message || e.toString();
            this.Stats.Error++;
        }

        result.finishedAt = this.Timestamp();
        result.durationMs = new Date().getTime() - result.startedAtMs;
        delete result.startedAtMs;
        this.Reset502();
        return result;
    },

    Open502: function (result) {
        if (!Host.Navigate502()) {
            result.status = "ERROR";
            result.message = "No fue posible abrir la pantalla 502.";
            this.Stats.Error++;
            return false;
        }
        return this.Ensure502(result);
    },

    Ensure502: function (result) {
        if (Host.ScreenContains("502 RESERVATIONS/RATES"))
            return true;
        result.status = "ERROR";
        result.message = "Pantalla 502 no disponible.";
        this.Stats.Error++;
        return false;
    },

    SearchReservation: function (reservation, result) {
        Logger.Info("Buscando reservacion: " + reservation);
        if (!Host.SendKeys("dr")) {
            result.status = "ERROR";
            result.message = "No fue posible seleccionar DR.";
            return false;
        }
        for (var i = 0; i < 19; i++) {
            if (!Host.Tab()) {
                result.status = "ERROR";
                result.message = "No fue posible navegar al campo de reservacion.";
                return false;
            }
        }
        if (!Host.SendKeys("r/" + reservation) || !Host.Enter()) {
            result.status = "ERROR";
            result.message = "No fue posible enviar la reservacion.";
            return false;
        }
        Host.Sleep(TIMEOUT.AfterReservationSearch);
        return true;
    },

    HasScreenError: function () {
        return Host.ScreenContains("ERROR - SEE HIGHLIGHTED FIELDS") ||
            Host.ScreenContains("INVALID") ||
            Host.ScreenContains("NOT AUTHORIZED");
    },

    ReservationNotFound: function () {
        return Host.ScreenContains("RESERVATION NOT FOUND") ||
            Host.ScreenContains("NOT FOUND") ||
            Host.ScreenContains("NO RECORD");
    },

    ReadWPA: function () {
        var position = Host.FindText("WPA");
        var value = "";
        if (position)
            value = Host.ReadText(position.Row, position.Column + 3, 6);
        if (!value || this.Trim(value) == "")
            value = Host.ReadText(PROCESS.FixedWpaRow, PROCESS.FixedWpaColumn, PROCESS.FixedWpaLength);
        return this.NormalizeWPA(value);
    },

    NormalizeWPA: function (value) {
        value = this.Trim(value || "").substring(0, 4).toUpperCase();
        if (!value)
            return "0000";
        var normalized = "";
        for (var i = 0; i < value.length; i++) {
            var character = value.charAt(i);
            if (character == "A") normalized += "4";
            else if (character == "Y") normalized += "1";
            else if (character == "M") normalized += "2";
            else if (character == "X" || character == "N") normalized += "0";
            else normalized += character;
        }
        return normalized;
    },

    HandleEspon: function () {
        var value = Host.ReadText(24, 21, 5) || "";
        if (this.Trim(value) != "ESPON")
            return true;

        if (!Host.Enter())
            return false;

        for (var i = 0; i < 16; i++) {
            if (!Host.Tab())
                return false;
        }
        return true;
    },

    Reset502: function () {
        if (!Host.PF(12))
            return false;
        Host.Sleep(TIMEOUT.AfterCommand);
        return Host.Navigate502();
    },

    BuildResult: function (reservation) {
        return {
            reservation: reservation,
            success: false,
            status: "",
            wpa: "",
            message: "",
            attempts: 0,
            startedAt: this.Timestamp(),
            startedAtMs: new Date().getTime(),
            finishedAt: "",
            durationMs: 0
        };
    },

    BuildSummary: function () {
        return "Total=" + this.Stats.Total + ", OK=" + this.Stats.Correct +
            ", NOT_FOUND=" + this.Stats.NotFound + ", ERROR=" + this.Stats.Error;
    },

    ResetStats: function () {
        this.Stats.Total = 0;
        this.Stats.Correct = 0;
        this.Stats.NotFound = 0;
        this.Stats.Error = 0;
    },

    Trim: function (value) {
        return value.replace(/^\s+|\s+$/g, "");
    },

    Timestamp: function () {
        var now = new Date();
        return now.getFullYear() + "-" + this.Pad(now.getMonth() + 1) + "-" +
            this.Pad(now.getDate()) + "T" + this.Pad(now.getHours()) + ":" +
            this.Pad(now.getMinutes()) + ":" + this.Pad(now.getSeconds());
    },

    Pad: function (value) {
        return value < 10 ? "0" + value : value.toString();
    }
};
