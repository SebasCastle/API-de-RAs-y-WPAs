/******************************************************************************
 * Logger.js
 *
 * Utilidad para registrar eventos del Worker.
 * Si ocurre un error al escribir el log, el proceso continúa.
 ******************************************************************************/

var Logger = {

    File: null,

    /**********************************************************************
     * Inicializa el archivo de log.
     **********************************************************************/
    Start: function () {

        try {

            var now = new Date();

            var fileName =
                now.getFullYear() +
                this.Pad(now.getMonth() + 1) +
                this.Pad(now.getDate()) +
                ".log";

            this.File = PATH.Logs + fileName;

            this.EnsureFolder(PATH.Root);
            this.EnsureFolder(PATH.Logs);

            this.Info("==================================================");
            this.Info("Worker iniciado");
            this.Info("Versión: " + WORKER.Version);
            this.Info("==================================================");

        }
        catch (e) {

        }

    },


    /**********************************************************************
     * Finaliza el log.
     **********************************************************************/
    Finish: function () {

        this.Info("==================================================");
        this.Info("Worker finalizado");
        this.Info("==================================================");

    },


    /**********************************************************************
     * Información.
     **********************************************************************/
    Info: function (message) {

        this.Write("INFO", message);

    },


    /**********************************************************************
     * Advertencia.
     **********************************************************************/
    Warn: function (message) {

        this.Write("WARN", message);

    },


    /**********************************************************************
     * Error.
     **********************************************************************/
    Error: function (message) {

        this.Write("ERROR", message);

    },


    /**********************************************************************
     * Escribe una línea en el log.
     **********************************************************************/
    Write: function (level, message) {

        try {

            var line =
                this.Time() +
                " [" +
                level +
                "] " +
                message;

            WScript.Echo(line);

            var file;

            if (fso.FileExists(this.File))
                file = fso.OpenTextFile(this.File, 8);
            else
                file = fso.CreateTextFile(this.File, true);

            file.WriteLine(line);

            file.Close();

        }
        catch (e) {

            // Nunca detener el Worker por un error de log.

        }

    },


    /**********************************************************************
     * Obtiene la hora actual.
     **********************************************************************/
    Time: function () {

        var now = new Date();

        return this.Pad(now.getHours()) + ":" +
               this.Pad(now.getMinutes()) + ":" +
               this.Pad(now.getSeconds());

    },


    /**********************************************************************
     * Agrega un cero a la izquierda.
     **********************************************************************/
    Pad: function (value) {

        if (value < 10)
            return "0" + value;

        return value.toString();

    },

    /**********************************************************************
     * Crea una carpeta y sus padres cuando aun no existen.
     **********************************************************************/
    EnsureFolder: function (folderPath) {

        if (fso.FolderExists(folderPath))
            return;

        var parent = fso.GetParentFolderName(folderPath);

        if (parent && !fso.FolderExists(parent))
            this.EnsureFolder(parent);

        fso.CreateFolder(folderPath);

    }

};
