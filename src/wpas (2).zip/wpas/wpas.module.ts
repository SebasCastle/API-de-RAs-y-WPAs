import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { WpaJob } from "./entities/wpa-job.entity";
import { WPA } from "./entities/wpa.entity";
import { WpaWorker } from "./entities/wpa-worker.entity";
import { WpaController } from "./wpas.controller";
import { WpasService } from "./wpas.service";
import { WorkerActivationService } from "./worker-activation.service";

@Module({
  imports: [TypeOrmModule.forFeature([WPA, WpaJob, WpaWorker])],
  controllers: [WpaController],
  providers: [WpasService, WorkerActivationService],
  exports: [WpasService],
})
export class WpasModule {}
