import { Injectable, Logger } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { DataSource, In, MoreThanOrEqual, Repository } from "typeorm";
import { CreateWpaJobDto } from "./dto/create-wpa-job.dto";
import { WpaJob, WpaJobStatus } from "./entities/wpa-job.entity";
import { WPA } from "./entities/wpa.entity";
import { WpaWorker, WorkerStatus } from "./entities/wpa-worker.entity";
import { WpaSyncPayload } from "./interfaces/wpa-result.interface";
import { WorkerHeartbeatDto } from "./dto/worker-heartbeat.dto";
import { WorkerActivationService } from "./worker-activation.service";

/** Logica WPA usando MySQL mediante TypeORM. */
@Injectable()
export class WpasService {
  private readonly logger = new Logger(WpasService.name);

  constructor(
    @InjectRepository(WPA) private readonly wpaRepository: Repository<WPA>,
    @InjectRepository(WpaJob)
    private readonly jobRepository: Repository<WpaJob>,
    @InjectRepository(WpaWorker)
    private readonly workerRepository: Repository<WpaWorker>,
    private readonly dataSource: DataSource,
    private readonly workerActivationService: WorkerActivationService,
  ) {}

  async crearJob(
    input: CreateWpaJobDto = {},
  ): Promise<{ job: WpaJob; activation: unknown }> {
    const job = await this.jobRepository.save(
      this.jobRepository.create({
        source: input.source || "FILE",
        reservations: input.reservations || [],
        status: WpaJobStatus.PENDING,
      }),
    );

    //activr una instnacia
    const activation = (await this.hayWorkerOnline())
      ? { requested: false, reason: "Un worker ya esta disponible." }
      : await this.workerActivationService.solicitarInicio(String(job.id));
    return { job, activation };
  }

  /** Reclama un job dentro de una transaccion para que dos workers no obtengan el mismo. */
  async reclamarSiguienteJob(workerId: string): Promise<WpaJob | null> {
    await this.registrarHeartbeat({ workerId, status: WorkerStatus.ONLINE });
    const job = await this.dataSource.transaction(async (manager) => {
      const repository = manager.getRepository(WpaJob);
      const pending = await repository
        .createQueryBuilder("job")
        .setLock("pessimistic_write")
        .where("job.status = :status", { status: WpaJobStatus.PENDING })
        .orderBy("job.created_at", "ASC")
        .getOne();
      if (!pending) return null;
      pending.status = WpaJobStatus.RUNNING;
      pending.workerId = workerId;
      pending.startedAt = new Date();
      return repository.save(pending);
    });

    if (job)
      await this.registrarHeartbeat({
        workerId,
        status: WorkerStatus.BUSY,
        jobId: String(job.id),
      });
    return job;
  }

  async registrarHeartbeat(input: WorkerHeartbeatDto): Promise<WpaWorker> {
    let worker = await this.workerRepository.findOneBy({
      workerId: input.workerId,
    });
    if (!worker)
      worker = this.workerRepository.create({ workerId: input.workerId });
    worker.status = input.status || WorkerStatus.ONLINE;
    worker.currentJobId = input.jobId || null;
    worker.lastHeartbeatAt = new Date();
    worker.metadata = input.metadata || {};
    return this.workerRepository.save(worker);
  }

  async recibirResultados(
    jobId: string,
    payload: WpaSyncPayload,
  ): Promise<void> {
    const id = this.toJobId(jobId);
    const job = await this.jobRepository.findOneBy({ id });
    if (!job) throw new Error("El job WPA no existe.");

    await this.dataSource.transaction(async (manager) => {
      const wpaRepository = manager.getRepository(WPA);
      for (const result of payload.results || []) {
        let wpa = await wpaRepository.findOneBy({ resNum: result.reservacion });
        if (!wpa)
          wpa = wpaRepository.create({
            resNum: result.reservacion,
            attempts: 0,
          });
        wpa.wpa = result.wpa || "";
        wpa.status = result.status || payload.status;
        wpa.message = payload.message || "";
        wpa.processedAt = new Date();
        wpa.attempts += 1;
        await wpaRepository.save(wpa);
      }

      const jobRepository = manager.getRepository(WpaJob);
      job.status =
        payload.status === "success"
          ? WpaJobStatus.COMPLETED
          : WpaJobStatus.ERROR;
      job.result = payload;
      job.finishedAt = new Date();
      await jobRepository.save(job);
    });

    if (job.workerId)
      await this.registrarHeartbeat({
        workerId: job.workerId,
        status: WorkerStatus.ONLINE,
      });
    this.logger.log(
      `Job WPA ${jobId} finalizado con estado ${payload.status}.`,
    );
  }

  obtenerJob(jobId: string) {
    return this.jobRepository.findOneBy({ id: this.toJobId(jobId) });
  }
  obtenerResultados(jobId?: string) {
    return jobId
      ? this.obtenerJob(jobId)
      : this.jobRepository.findOne({
          where: { status: In([WpaJobStatus.COMPLETED, WpaJobStatus.ERROR]) },
          order: { finishedAt: "DESC" },
        });
  }
  obtenerWorkers() {
    return this.workerRepository.find({ order: { lastHeartbeatAt: "DESC" } });
  }

  async obtenerReservacionesDelJob(jobId: string): Promise<string[]> {
    const job = await this.obtenerJob(jobId);
    if (!job) throw new Error("El job WPA no existe.");
    return job.reservations || [];
  }

  private async hayWorkerOnline(): Promise<boolean> {
    return (
      (await this.workerRepository.count({
        where: {
          status: In([WorkerStatus.ONLINE, WorkerStatus.BUSY]),
          lastHeartbeatAt: MoreThanOrEqual(new Date(Date.now() - 90_000)),
        },
      })) > 0
    );
  }

  private toJobId(jobId: string): number {
    const id = Number(jobId);
    if (!Number.isInteger(id) || id < 1)
      throw new Error("El id del job WPA no es valido.");
    return id;
  }
}
